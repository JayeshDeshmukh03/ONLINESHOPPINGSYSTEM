
/**
 * This class constraints the product type in to four kinds.
 */
public enum ProductType{
	GAME,MUSIC,MOVIE,TV
}
